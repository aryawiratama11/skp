		<div class="page-footer">
            <div class="page-footer-inner"> <?php echo date('Y'); ?> &copy; Metronic Theme By
                <a target="_blank" href="http://keenthemes.com">Keenthemes</a> &nbsp;|&nbsp;
                <a href="#" title="selamat pagi" target="_blank">Arya Wiratama-151411513015</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>